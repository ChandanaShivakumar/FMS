﻿using FMSSprint1.DAL;
using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.BAL
{
    public class AdministratorBAL
    {
        public static int UserInsertion(Users user)
        {
            try
            {
                if (user != null)
                {
                    int result = AdministratorDAL.insertUser(user);
                    Utility.PrintMessage("Successfully Added", true);
                    return result;
                }
                else
                {
                    Utility.PrintMessage("Data Not Added", false);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                Utility.PrintMessage(ex.ToString(), false);
            }
            return 0;
        }
    }
}
