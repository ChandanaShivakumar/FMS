﻿using FMSSprint1.DAL;
using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.BAL
{
    public class LoginBAL
    {
        public static int UserLogin(Login log)
        {
            try
            {
                if (log != null)
                {
                    int result = LoginDAL.loginUser(log);
                    Utility.PrintMessage("Successfully Logged In", true);
                    return result;
                }
                else
                {
                    Utility.PrintMessage("Cannot Log In", false);
                    return -1;
                }
            }
            catch (Exception ex)
            {
                Utility.PrintMessage(ex.ToString(), false);
            }
            return 0;
        }

    }
}
