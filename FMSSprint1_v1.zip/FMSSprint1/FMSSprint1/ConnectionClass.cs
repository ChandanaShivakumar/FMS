﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1
{
    public static class ConnectionClass
    {
        private static string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["mysqlconnection"].ConnectionString;
        private static SqlConnection con = new SqlConnection(connectionstring);
        public static SqlConnection myConnection()
        {
            return con;
        }
    }
}
