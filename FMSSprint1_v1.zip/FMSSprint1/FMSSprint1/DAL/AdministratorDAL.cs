﻿using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.DAL
{
    public class AdministratorDAL
    {
        public static int insertUser(Users user)
        {
            SqlConnection con = ConnectionClass.myConnection();
            string query = "insert into users(Firstname, Lastname, Address, City, State, Pincode, Mobilenumber, RoleId) values (@Firstname, @Lastname, @Address, @City, @State, @Pincode, @Mobilenumber, @RoleId)";
            SqlCommand com = new SqlCommand(query, con);
            com.Parameters.AddWithValue("@Firstname", user.Firstname);
            com.Parameters.AddWithValue("@Lastname", user.Lastname);
            com.Parameters.AddWithValue("@Address", user.Address);
            com.Parameters.AddWithValue("@City", user.City);
            com.Parameters.AddWithValue("@State", user.State);
            com.Parameters.AddWithValue("@Pincode", user.Pincode);
            com.Parameters.AddWithValue("@Mobilenumber", user.Mobilenumber);
            com.Parameters.AddWithValue("@RoleId", user.RoleId);
            con.Open();
            int result = com.ExecuteNonQuery();
            con.Close();
            return result;
        }

        public static int getUserId(Users user)
        {
            SqlConnection con = ConnectionClass.myConnection();
            string query = "select MAX(UserId) from Users";
            SqlCommand com = new SqlCommand(query, con);
            com.Parameters.AddWithValue("@UserId", user.UserId);
            con.Open();
            int result = com.ExecuteNonQuery();
            con.Close();
            return result;
        }
    }
}
