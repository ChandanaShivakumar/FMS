﻿using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.DAL
{
    internal class CourseSubjectDAL
    {
        public static int insertUser(CourseSubject cs)
        {
            SqlConnection con = ConnectionClass.myConnection();
            string query = "insert into CourseSubject(CourseId,SubjectId)+ values(@CourseId,@SubjectId)";
            SqlCommand com = new SqlCommand(query, con);
            com.Parameters.AddWithValue("@Courseid", cs.CourseId);
            com.Parameters.AddWithValue("@Subjectid", cs.SubjectId);

            con.Open();
            int result = com.ExecuteNonQuery();
            con.Close();
            return result;
        }
    }
}
