﻿using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.DAL
{
    internal class CoursesDAL
    {
        public static int insertCourse(Course course)
        {
            SqlConnection con = ConnectionClass.myConnection();
            string query1 = "insert into Course(CourseId,Coursename,Coursecredit,DeptId) values (@CourseId,@Coursename,@Coursecredit,@DeptId)";
            SqlCommand cmd = new SqlCommand(query1, con);

            cmd.Parameters.AddWithValue("@Courseid", course.CourseId);
            cmd.Parameters.AddWithValue("@Coursename", course.Coursename);
            cmd.Parameters.AddWithValue("@Coursecredit", course.Coursecredit);
            cmd.Parameters.AddWithValue("@Deptid", course.DeptId);
            con.Open();
            int soln = cmd.ExecuteNonQuery();
            con.Close();
            return soln;
        }
    }
}
