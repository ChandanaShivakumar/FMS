﻿using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.DAL
{
    public class LoginDAL
    {
        public static int loginUser(Login log)
        {
            SqlConnection con = ConnectionClass.myConnection();
            string query = "insert into login(Username, Password) values (@Username, @Password)";
            SqlCommand com = new SqlCommand(query, con);
            com.Parameters.AddWithValue("@Username", log.Username);
            com.Parameters.AddWithValue("@Password", log.Password);
            con.Open();
            int result = com.ExecuteNonQuery();
            con.Close();
            return result;
        }
    }
}
