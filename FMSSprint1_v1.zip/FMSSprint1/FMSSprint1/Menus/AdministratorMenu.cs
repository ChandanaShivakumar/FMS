﻿using FMSSprint1.BAL;
using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1.Menus
{
    public class AdministratorMenu
    {
        public AdministratorMenu()
        {
            int c;
            do
            {
                Console.WriteLine("1:Insert User\t 2:Login User \t 3:Exit");
                c = Utility.GetValidIntInput("Enter your choice : ");
                switch (c)
                {
                    case 1:
                        InsertUser();
                        break;
                    case 2:
                        LoginUser();
                        break;
                    case 3:
                        break;
                    default:
                        Utility.PrintMessage("Invalid Choice", false);
                        break;
                }
            } while (c != 3);
        }
        
        public static void InsertUser()
        {
            Users user = new Users();
            user.Firstname = Utility.ValidateName("First Name : ");
            user.Lastname = Utility.ValidateName("Last Name : ");
            user.Address = Utility.ValidateAddress("Address : ");
            user.City = Utility.ValidateName("City : ");
            user.State = Utility.ValidateName("State : ");
            user.Pincode = Utility.ValidatePincode("Pin Code : ");
            user.Mobilenumber = Utility.ValidatePhoneNumber("Mobile Number : ");
            user.RoleId = Utility.GetValidIntInput("RoleId");
            AdministratorBAL.UserInsertion(user);

        }

        public static void LoginUser()
        {
            Login log = new Login();
            log.Username = Utility.ValidateUsername("User Name : ");
            log.Password = Utility.ValidatePassword("Password : ");
            LoginBAL.UserLogin(log);
        }
    }
}
