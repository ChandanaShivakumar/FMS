﻿using FMSSprint1.BAL;
using FMSSprint1.DAL;
using FMSSprint1.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMSSprint1
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Users us = new Users();
            //Login lo = new Login();
            //Console.WriteLine("Here is the userId");
            //lo.UserId = us.UserId;
            //int result1 = AdministratorDAL.getUserId(us);
            //Console.WriteLine(result1);
            Console.WriteLine("ADMINISTRATOR MENU");
            new Menus.AdministratorMenu();
            Console.ReadKey();  
        }
    }
}
