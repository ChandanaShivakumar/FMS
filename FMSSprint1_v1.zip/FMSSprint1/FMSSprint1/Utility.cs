using System;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Text.RegularExpressions;

namespace FMSSprint1
{
    public static class Utility
    {
        private static CultureInfo culture = new CultureInfo("ms-MY");
        public static decimal GetValidDecimalInput(string input)
        {
            bool valid = false;
            string rawInput;
            decimal num = 0;

            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(input);
                valid = decimal.TryParse(rawInput, out num);
                if (!valid)
                    PrintMessage("Invalid input. Try again.", false);
            }

            return num;
        }

        public static int GetValidIntInput(string input)
        {
            bool valid = false;
            string rawInput;
            int num = 0;

            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(input);
                valid = Int32.TryParse(rawInput, out num);
                if (!valid)
                    PrintMessage("Invalid input. Try again.", false);
            }

            return num;
        }

       

        public static string GetRawInput(string message)
        {
            Console.Write($"Enter {message}: ");
            return Console.ReadLine().Trim(' ');
        }

        public static string GetHiddenConsoleInput()
        {
            StringBuilder input = new StringBuilder();
            while (true)
            {
                var key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter) break;
                if (key.Key == ConsoleKey.Backspace && input.Length > 0) input.Remove(input.Length - 1, 1);
                else if (key.Key != ConsoleKey.Backspace) input.Append(key.KeyChar);
            }
            return input.ToString();
        }

       
        public static void printDotAnimation(int timer = 10)
        {
            for (var x = 0; x < timer; x++)
            {
                System.Console.Write(".");
                Thread.Sleep(100);
            }
            Console.WriteLine();
        }

        public static string Formatnum(decimal amt)
        {
            return String.Format(culture, "{0:C2}", amt);
        }

        public static void PrintMessage(string msg, bool success)
        {
            if (success)
                Console.ForegroundColor = ConsoleColor.Yellow;
            else
                Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine(msg);
            Console.ResetColor();
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }
        public static string ValidateAddress(string msg)
        {
            bool valid = false;
            string rawInput = "";
            Regex rgx = new Regex(@"^[A-Za-z0-9? ,_-]+$");
            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = rgx.IsMatch(rawInput);
                if (!valid)
                    PrintMessage("Invalid input. Name doesn't contain Special Characters Try again.", false);

                else
                    break;
            }
            return rawInput;

        }

        public static string ValidateUsername(string msg)
        {
            bool valid = false;
            string rawInput = "";
            Regex rgx = new Regex(@"^[A-Za-z0-9? ,_-]+$");
            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = rgx.IsMatch(rawInput);
                if (!valid)
                    PrintMessage("Invalid input. Name doesn't contain Special Characters Try again.", false);

                else
                    break;
            }
            return rawInput;

        }
        public static string ValidateName(string msg)
        {
            bool valid = false;
            string rawInput = "";
            Regex rgx = new Regex(@"^[A-Za-z\s]{3,25}$");
            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = rgx.IsMatch(rawInput);
                if (!valid)
                    PrintMessage("Invalid input. Name doesn't contain Special Characters Try again.", false);

                else
                    break;
            }
            return rawInput;

        }
        public static string ValidatePhoneNumber(string msg)
        {
            bool valid = false;
            string rawInput = "";
            Regex rgx = new Regex(@"^[0-9]{10}$");
            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = rgx.IsMatch(rawInput);
                if (!valid)
                    PrintMessage("Enter Valid Mobile Number",false);

                else
                    break;
            }
            return rawInput;

        }

        public static string ValidatePassword(string msg)
        {
            bool valid = false;
            string rawInput = "";
            Regex rgx = new Regex(@"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$");
            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = rgx.IsMatch(rawInput);
                if (!valid)
                    PrintMessage("Enter Valid Password", false);

                else
                    break;
            }
            return rawInput;

        }

        public static string ValidatePincode(string msg)
        {
            bool valid = false;
            string rawInput = "";
            Regex rgx = new Regex(@"^[1-9]{1}[0-9]{5}$");
            // Get user's input input type is valid
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = rgx.IsMatch(rawInput);
                if (!valid)
                    PrintMessage("Enter Valid Pin Code", false);

                else
                    break;
            }
            return rawInput;

        }
        public static DateTime ValidateDate(string msg)
        {
            bool valid = false;
            string rawInput = "";
            DateTime dt=DateTime.Now;
            //Regex rgx = new Regex(@"^[]$");
            //Validate Date
            while (!valid)
            {
                rawInput = GetRawInput(msg);
                valid = DateTime.TryParse(rawInput,out dt);
                if (!valid)
                    PrintMessage("Enter Valid Date (MM/DD/YYYY)", false);

                else
                    break;
            }
            return dt;

        }

    }
}